export class Cliente{
    nome;
    cpf;
}