//Console.log("Trabalhando com variáveis");
console.log("Trabalhando com variáveis");
//JS é case sensitive

const idade = 29;
const nome = "Ricardo";

//não fazer
//mes = "Janeiro";