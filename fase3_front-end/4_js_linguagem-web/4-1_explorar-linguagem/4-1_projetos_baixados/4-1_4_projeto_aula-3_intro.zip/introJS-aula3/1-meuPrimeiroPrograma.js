console.log("Meu Primeiro programa: trabalhando com variáveis");

const idade = 26;

console.log("idade");
console.log(idade);
console.log(idade+2);
console.log(idade-2);
console.log(idade/2);

const idadeSomada = idade+2;
console.log(idadeSomada);
