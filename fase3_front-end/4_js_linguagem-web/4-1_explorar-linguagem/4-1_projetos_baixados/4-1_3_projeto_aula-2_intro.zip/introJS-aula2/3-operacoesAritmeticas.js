console.log("Operações Aritiméticas");

console.log(2+2);
console.log(10 + 8 * 2);
console.log((10 + 8) * 2);

console.log("ano" + 2020);
console.log("2" + "2");