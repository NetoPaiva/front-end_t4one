console.log("Trabalhando com atribuição de variáveis");
const idade = 29;
const primeiroNome = "Ricardo";
const sobrenome = "Bugan";

//console.log(nome + " " + sobrenome)
console.log(primeiroNome, sobrenome)
console.log(`Meu nome é ${primeiroNome} ${sobrenome}`);

let contador = 0
contador = contador +1
const nomeCompleto = primeiroNome + sobrenome;
console.log(nomeCompleto);
nomeCompleto =2;
